package com.example.calculator;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends Activity {

    private static final int BG = Color.parseColor("#0E0E11");
    private static final String OPS = "÷×−+";

    // خلفية متدرجة مميزة لكل رقم من 0 إلى 9
    private static final int[][] DIGIT_GRADIENTS = {
            {0xFF485563, 0xFF29323C}, // 0 رمادي أزرق
            {0xFFFF416C, 0xFFFF4B2B}, // 1 أحمر
            {0xFF2193B0, 0xFF6DD5ED}, // 2 أزرق سماوي
            {0xFF11998E, 0xFF38EF7D}, // 3 أخضر
            {0xFF8E2DE2, 0xFF4A00E0}, // 4 بنفسجي
            {0xFF00C6FF, 0xFF0072FF}, // 5 أزرق
            {0xFFF953C6, 0xFFB91D73}, // 6 وردي غامق
            {0xFF667EEA, 0xFF764BA2}, // 7 نيلي
            {0xFFFF758C, 0xFFFF7EB3}, // 8 وردي
            {0xFF0F2027, 0xFF2C5364}  // 9 أخضر مزرق داكن
    };
    private static final int[] ORANGE = {0xFFFF9F0A, 0xFFFF6A00};
    private static final int[] FUNC = {0xFF5A5A62, 0xFF3C3C42};

    private static final String[][] KEYS = {
            {"C", "⌫", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"0", ".", "="}
    };

    private final StringBuilder expr = new StringBuilder();
    private boolean justEvaluated = false;

    private TextView exprView;
    private TextView resultView;
    private TextView soundToggle;
    private FrameLayout overlay;

    private SoundPool pool;
    private final HashMap<String, Integer> sounds = new HashMap<>();
    private boolean soundOn = true;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("calc", MODE_PRIVATE);
        soundOn = prefs.getBoolean("sound", true);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        initSounds();

        overlay = new FrameLayout(this);
        overlay.setBackgroundColor(BG);
        overlay.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setFitsSystemWindows(true);
        overlay.addView(main, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipChildren(false);
        content.setPadding(dp(12), dp(8), dp(12), dp(12));
        main.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

        // ---------- منطقة العرض ----------
        FrameLayout displayFrame = new FrameLayout(this);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.END);
        col.setPadding(dp(12), 0, dp(12), dp(8));

        exprView = new TextView(this);
        exprView.setTextColor(Color.parseColor("#9A9AA2"));
        exprView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        exprView.setMaxLines(1);
        exprView.setAutoSizeTextTypeUniformWithConfiguration(16, 30, 1, TypedValue.COMPLEX_UNIT_SP);
        exprView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));

        resultView = new TextView(this);
        resultView.setTextColor(Color.WHITE);
        resultView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        resultView.setMaxLines(1);
        resultView.setAutoSizeTextTypeUniformWithConfiguration(26, 64, 2, TypedValue.COMPLEX_UNIT_SP);
        resultView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        resultView.setText("0");

        col.addView(exprView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));
        col.addView(resultView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(84)));
        displayFrame.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        soundToggle = new TextView(this);
        soundToggle.setGravity(Gravity.CENTER);
        soundToggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        GradientDrawable toggleBg = new GradientDrawable();
        toggleBg.setShape(GradientDrawable.OVAL);
        toggleBg.setColor(0x22FFFFFF);
        soundToggle.setBackground(toggleBg);
        updateSoundIcon();
        soundToggle.setOnClickListener(v -> {
            soundOn = !soundOn;
            prefs.edit().putBoolean("sound", soundOn).apply();
            updateSoundIcon();
            if (soundOn) playSound("5");
        });
        displayFrame.addView(soundToggle, new FrameLayout.LayoutParams(dp(44), dp(44),
                Gravity.TOP | Gravity.END));

        content.addView(displayFrame, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 3f));

        // ---------- لوحة الأزرار ----------
        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setClipChildren(false);
        content.addView(pad, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 5f));

        ArrayList<Button> all = new ArrayList<>();
        for (String[] row : KEYS) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setClipChildren(false);
            for (String key : row) {
                Button b = makeButton(key);
                all.add(b);
                r.addView(b, buttonParams(key.equals("=") ? 2f : 1f));
            }
            pad.addView(r, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        }

        setContentView(overlay);

        // حركة دخول متتابعة للأزرار
        for (int i = 0; i < all.size(); i++) {
            Button b = all.get(i);
            b.setAlpha(0f);
            b.setTranslationY(dp(40));
            b.animate().alpha(1f).translationY(0f)
                    .setStartDelay(i * 25L).setDuration(340)
                    .setInterpolator(new DecelerateInterpolator(2f)).start();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pool != null) pool.release();
    }

    // ---------- بناء الأزرار ----------

    private Button makeButton(final String label) {
        final Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setShadowLayer(6f, 0f, 2f, 0x66000000);
        b.setPadding(0, 0, 0, 0);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setStateListAnimator(null);
        b.setElevation(dp(5));

        GradientDrawable shape = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, colorsFor(label));
        shape.setCornerRadius(dp(26));
        shape.setStroke(dp(1), 0x26FFFFFF);
        b.setBackground(shape);

        // حركة الضغط: انكماش سريع ثم ارتداد
        b.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().cancel();
                    v.animate().scaleX(0.86f).scaleY(0.86f).setStartDelay(0).setDuration(70)
                            .setInterpolator(new DecelerateInterpolator()).start();
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    playSound(label);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(280)
                            .setInterpolator(new OvershootInterpolator(3f)).start();
                    break;
                default:
                    break;
            }
            return false;
        });

        b.setOnClickListener(v -> {
            flyLabel(b, label);
            onKey(label);
        });
        return b;
    }

    private int[] colorsFor(String label) {
        if (label.length() == 1 && Character.isDigit(label.charAt(0))) {
            return DIGIT_GRADIENTS[label.charAt(0) - '0'];
        }
        if (OPS.contains(label) || label.equals("=")) return ORANGE;
        return FUNC;
    }

    private LinearLayout.LayoutParams buttonParams(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, weight);
        int m = dp(5);
        p.setMargins(m, m, m, m);
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- الحركات ----------

    /** الرقم يطير من الزر إلى الشاشة */
    private void flyLabel(View from, String text) {
        if (text.equals("C") || text.equals("⌫") || text.equals("=")) return;

        final TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setShadowLayer(8f, 0f, 2f, 0x99000000);

        int[] f = new int[2];
        from.getLocationOnScreen(f);
        int[] o = new int[2];
        overlay.getLocationOnScreen(o);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(from.getWidth(), from.getHeight());
        lp.leftMargin = f[0] - o[0];
        lp.topMargin = f[1] - o[1];
        overlay.addView(t, lp);

        int[] r = new int[2];
        resultView.getLocationOnScreen(r);
        float dx = (r[0] + resultView.getWidth() - dp(48)) - (f[0] + from.getWidth() / 2f);
        float dy = (r[1] + resultView.getHeight() / 2f) - (f[1] + from.getHeight() / 2f);

        t.animate().translationX(dx).translationY(dy)
                .scaleX(0.35f).scaleY(0.35f).alpha(0f)
                .setDuration(380)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(() -> overlay.removeView(t))
                .start();
    }

    private void bump(View v) {
        v.animate().cancel();
        v.setTranslationY(dp(8));
        v.setAlpha(0.5f);
        v.animate().translationY(0f).alpha(1f).setDuration(150).start();
    }

    private void popBig(View v) {
        v.animate().cancel();
        v.setScaleX(1.14f);
        v.setScaleY(1.14f);
        v.setTranslationY(0f);
        v.setAlpha(1f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(300)
                .setInterpolator(new OvershootInterpolator(3f)).start();
    }

    private void shake(View v) {
        ObjectAnimator a = ObjectAnimator.ofFloat(v, "translationX",
                0f, -dp(12), dp(12), -dp(8), dp(8), 0f);
        a.setDuration(320);
        a.start();
    }

    // ---------- الصوت ----------

    private void initSounds() {
        pool = new SoundPool.Builder()
                .setMaxStreams(6)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build())
                .build();

        // سلّم نغمي صاعد: كل رقم له نغمة مختلفة
        int[] degrees = {0, 2, 4, 7, 9, 12, 14, 16, 19, 21};
        for (int d = 0; d < 10; d++) {
            double freq = 392.0 * Math.pow(2.0, degrees[d] / 12.0);
            sounds.put(String.valueOf(d), makeSound("k" + d, new double[]{freq}, 90, 38));
        }
        sounds.put("÷", makeSound("o1", new double[]{277}, 100, 32));
        sounds.put("×", makeSound("o2", new double[]{294}, 100, 32));
        sounds.put("−", makeSound("o3", new double[]{311}, 100, 32));
        sounds.put("+", makeSound("o4", new double[]{330}, 100, 32));
        sounds.put(".", makeSound("dot", new double[]{370}, 80, 40));
        sounds.put("%", makeSound("pct", new double[]{349}, 90, 36));
        sounds.put("⌫", makeSound("del", new double[]{247}, 90, 34));
        sounds.put("C", makeSound("clr", new double[]{196}, 140, 24));
        sounds.put("=", makeSound("eq", new double[]{523.25, 659.25, 783.99}, 240, 14));
    }

    /** يولّد نغمة قصيرة بصيغة WAV ويحمّلها في SoundPool */
    private int makeSound(String name, double[] freqs, int ms, double decay) {
        try {
            int sr = 22050;
            int n = sr * ms / 1000;
            ByteBuffer bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN);
            bb.put("RIFF".getBytes());
            bb.putInt(36 + n * 2);
            bb.put("WAVE".getBytes());
            bb.put("fmt ".getBytes());
            bb.putInt(16);
            bb.putShort((short) 1);
            bb.putShort((short) 1);
            bb.putInt(sr);
            bb.putInt(sr * 2);
            bb.putShort((short) 2);
            bb.putShort((short) 16);
            bb.put("data".getBytes());
            bb.putInt(n * 2);
            for (int i = 0; i < n; i++) {
                double t = i / (double) sr;
                double s = 0;
                for (double f : freqs) s += Math.sin(2 * Math.PI * f * t);
                s /= freqs.length;
                double env = Math.exp(-t * decay);
                double attack = Math.min(1.0, i / (sr * 0.003));
                double tail = Math.min(1.0, (n - i) / (sr * 0.004));
                bb.putShort((short) (s * env * attack * tail * 0.55 * 32767));
            }
            File file = new File(getCacheDir(), name + ".wav");
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write(bb.array());
            }
            return pool.load(file.getAbsolutePath(), 1);
        } catch (IOException e) {
            return 0;
        }
    }

    private void playSound(String key) {
        if (!soundOn) return;
        Integer id = sounds.get(key);
        if (id != null && id != 0) pool.play(id, 1f, 1f, 1, 0, 1f);
    }

    private void updateSoundIcon() {
        soundToggle.setText(soundOn ? "🔊" : "🔇");
    }

    // ---------- منطق الإدخال ----------

    private void onKey(String k) {
        switch (k) {
            case "C":
                expr.setLength(0);
                justEvaluated = false;
                exprView.setText("");
                break;
            case "⌫":
                justEvaluated = false;
                if (expr.length() > 0) expr.setLength(expr.length() - 1);
                break;
            case "=":
                doEquals();
                return;
            default:
                // بدء عملية جديدة عند كتابة رقم بعد النتيجة
                if (justEvaluated && !OPS.contains(k) && !k.equals("%")) {
                    expr.setLength(0);
                }
                justEvaluated = false;
                appendToken(k);
        }
        refresh();
    }

    private void doEquals() {
        String r = evaluate(expr.toString());
        if (r == null) return;
        if (r.equals("خطأ")) {
            resultView.setText(r);
            shake(resultView);
            return;
        }
        exprView.setText(expr.toString() + " =");
        expr.setLength(0);
        expr.append(r.replace("-", "−"));
        justEvaluated = true;
        resultView.setText(r);
        popBig(resultView);
    }

    private void appendToken(String k) {
        boolean isOp = OPS.contains(k);
        int n = expr.length();
        char last = n > 0 ? expr.charAt(n - 1) : 0;
        boolean lastIsOp = n > 0 && OPS.indexOf(last) >= 0;

        if (isOp) {
            if (n == 0) {
                if (k.equals("−")) expr.append(k); // رقم سالب
                return;
            }
            if (lastIsOp) expr.setCharAt(n - 1, k.charAt(0)); // استبدال المعامل
            else expr.append(k);
            return;
        }
        if (k.equals("%")) {
            if (n > 0 && (Character.isDigit(last) || last == '.')) expr.append(k);
            return;
        }
        if (k.equals(".")) {
            // منع نقطتين في الرقم نفسه
            for (int i = n - 1; i >= 0; i--) {
                char c = expr.charAt(i);
                if (c == '.') return;
                if (!Character.isDigit(c)) break;
            }
            if (n == 0 || lastIsOp) expr.append("0");
            expr.append(".");
            return;
        }
        // رقم: منع الأصفار الزائدة في بداية الرقم (05 تصبح 5)
        if (n > 0 && last == '0') {
            boolean startOfNumber = n == 1 || OPS.indexOf(expr.charAt(n - 2)) >= 0;
            if (startOfNumber) {
                expr.setCharAt(n - 1, k.charAt(0));
                return;
            }
        }
        expr.append(k);
    }

    private void refresh() {
        if (!justEvaluated) exprView.setText(expr.toString());
        if (expr.length() == 0) {
            resultView.setText("0");
            bump(resultView);
            return;
        }
        String r = evaluate(expr.toString());
        if (r != null) resultView.setText(r);
        bump(resultView);
    }

    // ---------- المقيِّم ----------

    private String evaluate(String s) {
        // تجاهل المعامل المعلّق في النهاية
        while (s.length() > 0 && OPS.indexOf(s.charAt(s.length() - 1)) >= 0) {
            s = s.substring(0, s.length() - 1);
        }
        if (s.isEmpty()) return null;
        try {
            Parser p = new Parser(s);
            BigDecimal v = p.parseExpr();
            if (p.pos != s.length()) return "خطأ";
            v = v.round(new MathContext(12));
            String out = v.stripTrailingZeros().toPlainString();
            return out.equals("-0") ? "0" : out;
        } catch (RuntimeException e) {
            return "خطأ";
        }
    }

    private static class Parser {
        final String s;
        int pos = 0;

        Parser(String s) {
            this.s = s;
        }

        BigDecimal parseExpr() {
            BigDecimal v = parseTerm();
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (c == '+') {
                    pos++;
                    v = v.add(parseTerm());
                } else if (c == '−') {
                    pos++;
                    v = v.subtract(parseTerm());
                } else break;
            }
            return v;
        }

        BigDecimal parseTerm() {
            BigDecimal v = parseFactor();
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (c == '×') {
                    pos++;
                    v = v.multiply(parseFactor());
                } else if (c == '÷') {
                    pos++;
                    BigDecimal d = parseFactor();
                    if (d.signum() == 0) throw new ArithmeticException("div0");
                    v = v.divide(d, new MathContext(15));
                } else break;
            }
            return v;
        }

        BigDecimal parseFactor() {
            if (pos < s.length() && s.charAt(pos) == '−') {
                pos++;
                return parseFactor().negate();
            }
            int start = pos;
            while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) pos++;
            if (start == pos) throw new IllegalStateException("num");
            BigDecimal v = new BigDecimal(s.substring(start, pos));
            while (pos < s.length() && s.charAt(pos) == '%') {
                pos++;
                v = v.divide(BigDecimal.valueOf(100));
            }
            return v;
        }
    }
}
